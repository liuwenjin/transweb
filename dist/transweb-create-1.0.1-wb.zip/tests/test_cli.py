import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "transweb_create.py"


def run(*args):
    return subprocess.run(
        [sys.executable, str(SCRIPT), *args],
        cwd=str(ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )


class CliTests(unittest.TestCase):
    def test_help(self):
        result = run("--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("selftest", result.stdout)
        self.assertNotIn("ppt", result.stdout)

    def test_selftest_json(self):
        result = run("selftest", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["skill"], "transweb-create")

    def test_version(self):
        result = run("--version")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("1.0.1", result.stdout)

    def test_help_lists_offline_commands(self):
        result = run("--help")
        self.assertIn("demo", result.stdout)
        self.assertIn("selftest", result.stdout)

    def test_demo_json_offline(self):
        result = run("demo", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertFalse(payload["created"])
        self.assertFalse(payload["network"])
        self.assertIsNone(payload["link"])
        self.assertEqual(payload["documentType"], "agent")
        self.assertGreaterEqual(len(payload["preview"]["creationSteps"]), 3)

    def test_demo_skill_json_offline(self):
        result = run("demo", "skill", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["documentType"], "skill")

    def test_agent_dry_run_offline(self):
        result = run("agent", "--input", "把这份资料做成新人上手助手", "--dry-run", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertFalse(payload["created"])
        self.assertEqual(payload["mode"], "dry-run")

    def test_skill_dry_run_offline(self):
        result = run("skill", "--input", "把三段话总结成一句结论", "--dry-run", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["type"], "skill")

    def test_selftest_checks_offline_preview(self):
        result = run("selftest", "--json")
        payload = json.loads(result.stdout)
        names = {c["name"] for c in payload["checks"]}
        self.assertIn("offline-preview", names)
        self.assertIn("version-match", names)
        self.assertIn("frontmatter:author", names)


if __name__ == "__main__":
    unittest.main()
